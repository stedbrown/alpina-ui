# Changelog

## 0.11.0 · 25 November 2026

### Forms and scheduling

- Edit translations in German, French, Italian and Romansh with optional English, per-language completion and native form values. Choose tabs, parallel editors or textareas.
- Calendar and DatePicker mark federal and cantonal holidays with support for regional rules. `swissHolidays` and `addBusinessDays` work with local civil dates. The Swiss forms guide documents the geographic and historical scope.
- SwissAddressForm loads the official residential postcode directory on the first complete postcode. Select a locality and canton, including postcodes that cross cantonal boundaries, or enter an address manually. The self-contained catalog also works offline.

### Data and appearance

- BarChart, LineChart, Sparkline and ChartTable draw SVG data graphics with text descriptions and accessible data tables.
- The portal opens in automatic appearance. Its control cycles through automatic, light and dark and remembers the choice. Negative franc amounts use a mathematical minus with a localized spoken equivalent.
- The portal revises column alignment, heading hierarchy and spacing. [Before and after](https://alpina-ui.vercel.app/releases/0.11/) · [Design notes on GitHub](https://github.com/stedbrown/alpina-ui/blob/main/docs/release-0.11-design.md)

### Packaging and adoption

- Three production integration projects exercise a Next.js Server Action, React Router navigation and React Hook Form with Zod. CI builds each against the packed library.
- Per-component size budgets and tree-shaking checks run alongside React Server Component compatibility checks. [Component status](https://alpina-ui.vercel.app/status/) records maturity and the latest source change.

## 0.10.0 · 25 November 2026

### Layout and reading

- Inspect columns, margins and the four-pixel baseline with `GridOverlay`. Press Ctrl+Shift+G on the portal to toggle the overlay. Modular grid rows, named field arrangements and subgrids let adjacent cards share label and value tracks.
- Prose, descriptions and numeric roles now distinguish running text from data. The default reading measure is 66ch. Headings balance, paragraphs wrap with a ragged edge, and Swiss language tags select the appropriate hyphenation rules.
- The portal’s [design principles](https://alpina-ui.vercel.app/principles/) compare eight design decisions with paired, live examples and source notes.

### Swiss data and documents

- `CurrencyCHF` accepts `cashRounding` for five-centime cash totals. Digital amounts keep their ordinary two-decimal precision. The formatter makes Swiss grouping explicit across runtimes.
- Numeric Swiss dates use day, month and four-digit year. Callers can still request written month names. Calendar rows start on Monday and expose ISO week numbers, including at year boundaries.
- `UidInput` validates and formats Swiss business identifiers. `SwissAddressForm` supports eCH-0010 postal fields. Existing address-book integrations can continue using the compact form.
- Alpina’s full stylesheet prints A4 documents with physical margins, repeated table headings and link destinations. Selective CSS imports can use `alpina-ui/print.css`. The QR payment slip retains its dedicated page and physical measurements.

### Appearance and corrections

- `data-al-theme="auto"` follows the device. Dark mode uses a lighter red with black button labels. Motion tokens honor reduced motion and loading placeholders reserve a static area.
- Tablet navigation collapses into a menu. The theme control stays beside it, search hints fit, and the theme builder uses English for its invoice preview. The Swiss QR-bill preview scales to its available width.

### Verification

- Responsive checks visit every public page at 360, 768, 800, 1024 and 1440 px. The test suite also audits accessibility with axe, measures component rhythm at three widths, and compares component screenshots in both themes at four widths.

## 0.9.0 · 25 November 2026

- Added `asChild` composition, leaf refs, optional local Inter fonts, a Tailwind v4 token sheet and a live theme builder.
- Introduced Swiss QR-bills and IBAN, AHV and telephone inputs. Added login, dashboard, account settings and CHF pricing blocks to the CLI.
- Prepared manual npm publishing with provenance. [Upgrade notes](docs/release.md)

Earlier changes, including the original icon set and address-form alignment, are recorded in the [release history](docs/release.md).
