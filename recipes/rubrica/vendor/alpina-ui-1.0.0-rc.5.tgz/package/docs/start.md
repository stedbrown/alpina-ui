# Getting started

Alpina UI 1.0.0-rc.5 includes 97 installable React component entries and five copyable pages. The package contains ESM modules, TypeScript declarations, stylesheets and editable source. The Start and Swiss guides are also available in German, French and Italian. The address form provides field labels and error messages in all four Swiss national languages.

<!-- alpina-download -->

Find a component by name, copy a complete page, or try a working example before installing. The Italian–German address book lets you switch languages halfway through editing a contact. [Browse components](https://alpinaui.com/docs/components/) · [Copyable blocks](https://alpinaui.com/blocks/) · [Bilingual address book](https://alpinaui.com/examples/bilingual-address-book/)

## Install the package

If your application uses shadcn/ui, the migration guide shows how to keep both libraries in one project, connect Tailwind v4, and port each component family. [From shadcn/ui to Alpina](https://alpinaui.com/docs/guides/migration/)

In a React 18.2 or 19 project with Node.js 20 or later, install the versioned package directly from the portal.

```sh
npm install https://alpinaui.com/alpina-ui-1.0.0-rc.5.tgz
```

If you downloaded the archive first, run `npm install ./alpina-ui-1.0.0-rc.5.tgz` in the directory that contains it. Import the CSS once at your application entry point. The JavaScript modules can also run during server rendering.

```tsx
import "alpina-ui/styles.css"
import { CurrencyCHF, SwissDate } from "alpina-ui"

export function Summary() {
  return (
    <p>
      <CurrencyCHF amount={1280.5} locale="fr-CH" />
      {" · "}
      <SwissDate value="2026-11-24" locale="fr-CH" />
    </p>
  )
}
```

## Include a single component

For a smaller bundle, import the component module and its stylesheet. Component CSS includes the rules for its dependencies. Import the theme once. Pure formatters work without stylesheets.

```tsx
import "alpina-ui/theme.css"
import "alpina-ui/styles/button.css"
import { Button } from "alpina-ui/ui/button"

export function Confirm() {
  return <Button type="submit">Confirm</Button>
}
```

## Copy source files into your project

Once you install the package, the CLI works offline. `list` shows registry names. `add` copies the selected files, their dependencies, the theme, and the license notice to `components/alpina`. It preserves files you have edited. The optional `init` command copies the theme and its license notice.

```sh
npx --no-install alpina list
npx --no-install alpina add button icon canton-select
npx --no-install alpina add dialog --dir src/components/alpina --dry-run
npx --no-install alpina add --all
```

With copied sources, import the theme from `./components/alpina/theme.css` and components from paths such as `./components/alpina/ui/button` or `./components/alpina/swiss/canton-select`. Adjust the paths relative to the importing file. Each TSX file imports its own CSS and needs a bundler with CSS and TypeScript support. Relative `.js` imports follow the NodeNext convention.

To copy a complete page, run `npx --no-install alpina add block/dashboard`. The resulting `components/alpina/blocks/dashboard.tsx` uses the public package imports and accepts your invoice data. Load `alpina-ui/styles.css` once in the application. [Dashboard preview](https://alpinaui.com/blocks/dashboard/)

For a repository link, place `<Icon name="git-branch" size={18} />` beside the link text. The `iconNames` export lists every available name. [Browse icons](https://alpinaui.com/icons/) · [Icon reference](https://alpinaui.com/docs/components/icon/)

## Customize the theme

Library classes use the `al-` prefix. Apply the dark theme to an entire app or to one section. The default type stack starts with Helvetica Neue and Helvetica, followed by Arial and the system sans serif. Import `alpina-ui/fonts.css` to self-host Inter across platforms. Load custom variables after the theme. You can preview an accent, change the grid unit, check text contrast and copy the CSS in the theme builder. [Design guide](https://alpinaui.com/docs/guides/design/) · [Theme builder](https://alpinaui.com/themes/)

```tsx
<section data-al-theme="dark">
  <Button>Save</Button>
</section>
```

```css
.my-app {
  --al-accent: #eb0000;
  --al-on-accent: white;
  --al-radius: 0;
  --al-font: "Helvetica Neue", Helvetica, Arial, sans-serif;
}
```

## Set the interface language

Wrap a subtree in `AlpinaProvider` to share its locale. An explicit component `locale` wins over the nearest provider, and a nested provider overrides its parent. Components with English copy also support `en`. Pure formatters used in server actions or elsewhere outside React still take the locale as their positional argument. When using CLI source copies, import the provider from `swiss/alpina-provider` inside the same destination directory as the copied components.

```tsx
import { AlpinaProvider, FileInput } from "alpina-ui"

export function Attachments() {
  return <AlpinaProvider locale="it-CH"><FileInput name="attachments" /></AlpinaProvider>
}
```

## Runtime and accessibility

The Next.js 16 example renders two public sample invoices at `/invoices/[id]` with Cache Components enabled. The page supplies IDs with `generateStaticParams()`, awaits the route params on the server and passes the matching data to `InvoiceDocument`. A small client component owns the print button. For private invoices, read and authorize the request on the server behind a Suspense boundary. [Invoice route](https://github.com/stedbrown/alpina-ui/tree/main/integrations/next-app-router/app/invoices) · [Next.js routing](https://nextjs.org/docs/app/api-reference/functions/generate-static-params)

Three runnable projects exercise this package with a Next.js Server Action, React Router links and a React Hook Form backed by a Zod schema. Each includes a production build and a browser test. [Integration projects and setup](https://github.com/stedbrown/alpina-ui/tree/main/integrations)

Form controls use native HTML elements. Interactive components use the browser after hydration. Modals use `HTMLDialogElement.showModal()`. In frameworks with React Server Components, place `"use client"` in application components that manage interactive state, callbacks, or render props. You can import `formatCHF` and `formatSwissDate` in server code.

Test complete application flows with your labels, translations, and theme colors. The project includes automated keyboard and focus tests for interactive components.
